<?php
echo view('layouts/header');
echo view($main);
echo view('layouts/footer');
